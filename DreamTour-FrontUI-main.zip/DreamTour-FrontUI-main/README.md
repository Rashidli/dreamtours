# DreamTour

Responsive travel & tourism website — **Phase 1: frontend UI only**.

No backend, database, API, authentication, payment or CMS. All dynamic content
is static mock data (`src/js/data.js`). Interactions are handled with Alpine.js.

## Stack

- HTML5 (semantic, accessible)
- Tailwind CSS v4 (CSS-first, tokens in `src/css/main.css`)
- Alpine.js 3 (vendored to `src/js/vendor/alpine.min.js`)

## Setup

```bash
npm install        # installs Tailwind CLI + Alpine, copies Alpine into src/js/vendor
npm run dev         # watches src/css/main.css -> dist/main.css
```

Then open `index.html` (or run `npm run serve` for a local static server).

### Scripts

| Script              | Purpose                                            |
| ------------------- | -------------------------------------------------- |
| `npm run dev`       | Copy Alpine + watch/compile CSS                    |
| `npm run build`     | Copy Alpine + one-off minified CSS build           |
| `npm run copy:alpine` | Refresh the vendored Alpine build               |
| `npm run serve`     | Static file server on the project root             |

## Structure

```
index.html              Home (placeholder until Phase 3)
pages/                   All other pages (built section by section)
src/css/main.css         Tailwind entry + @theme design tokens
src/js/app.js            Alpine stores + reusable components
src/js/data.js           Mock content
src/js/vendor/           Vendored Alpine build (generated)
dist/main.css            Compiled stylesheet (generated)
assets/images/           Local imagery
```

## Design tokens

Defined in the `@theme` block of `src/css/main.css`:

- `brand-*` — crimson / rose (primary CTA + accent)
- `ink-*` — deep navy (headers, footers, dark bands)
- `sand-*` — warm off-white (alternating light sections)
- `font-display` (Poppins) / `font-sans` (Inter)
- `rounded-4xl` / `rounded-5xl`, `shadow-card` / `shadow-card-hover`
- `.container-page` and `.eyebrow` helpers in `@layer components`

## Workflow

Built incrementally, one page and one section at a time, each awaiting review
before the next begins.
